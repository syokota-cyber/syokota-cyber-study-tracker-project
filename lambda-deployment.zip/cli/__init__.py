"""
CLIパッケージ

コマンドラインインターフェース機能を提供します。
"""

from .main import main

__all__ = ["main"]
