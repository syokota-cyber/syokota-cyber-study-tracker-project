"""
APIパッケージ

FastAPIによるWeb API機能を提供します。
"""

from .routes import router

__all__ = ["router"]
