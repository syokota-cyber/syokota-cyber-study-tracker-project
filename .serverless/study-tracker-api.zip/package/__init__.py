# src/__init__.py
"""
StudyTracker - 学習進捗管理アプリケーション

このパッケージは学習記録の管理、分析、可視化機能を提供します。
"""

__version__ = "1.0.0"
__author__ = "StudyTracker Team"
