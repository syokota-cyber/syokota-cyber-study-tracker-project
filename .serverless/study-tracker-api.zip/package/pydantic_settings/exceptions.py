class SettingsError(ValueError):
    """Base exception for settings-related errors."""

    pass
